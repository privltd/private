export type DateType = {
  date?: number
  month?: string | number
  year?: number
  hour?: number
  minute?: number
}

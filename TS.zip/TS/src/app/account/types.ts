export type OutletContextType = {
  toggleOffcanvas: () => void
}
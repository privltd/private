type CurrencyType = '₹' | '$' | '€'

export const currency: CurrencyType = '$'

export const currentYear = new Date().getFullYear()

export const developedByLink = 'https://stackbros.in/'

export const developedBy = 'Stackbros'

export const buyLink = ''

export const basePath = ''

export const DEFAULT_PAGE_TITLE = ' Mizzle - Next Technology and Corporate Bootstrap Theme'

